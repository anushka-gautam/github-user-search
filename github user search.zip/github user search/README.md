# `GitHub User Finder` 



### GitHub User Finder ScreenShoot

### Live Preview Project
[View Demo Project](https://mian-ali.github.io/gitHub-UserFinder/)

<img src="screen.png" width=270 height=480>

![alt text]('screen.png')
